/* Build-specific, verified app downloads; never reads or deletes saved-game storage. */
const RELEASE = {"id":"a267acd4da06d7ee","label":"Admin-Level 100 \u00b7 Update-Fix 1","mainPack":"stickie-game-a862f69d3b8b9389.pck","files":{"FONT-LICENSE.txt":{"sha256":"7a083b136e64d064794c3419751e5c7dd10d2f64c108fe5ba161eae5e5958a93","bytes":8816},"GODOT-COPYRIGHT.txt":{"sha256":"cb1980c88089573bcacd7221d777c689bb8bbd778799f24c27fca0fe5f774d6d","bytes":100108},"GODOT-LICENSE.txt":{"sha256":"b0435e3b3e4e55238f05f4b306f30524a1b2e20147810d436eaa554fa6855c80","bytes":1149},"aktualisieren.html":{"sha256":"30d7c5bc4b39177d62ef278548b7c64f0bf21b7aec3da2ebe04b7482ca37e627","bytes":1070},"credits.html":{"sha256":"c13b6d217eddbafd3ef4a6c1f969f788eabed427e32c4f5bc64d6ff5c307fbee","bytes":542},"index.144x144.png":{"sha256":"c81dc09eb9298a7c687c94900fc4a8f64f622c58996de06d10d550a8be42c9c5","bytes":7187},"index.180x180.png":{"sha256":"ff44425cc4b3d1fd46c5bd7cc0a847d7356314fdff5760313fc15814dc6c174d","bytes":10199},"index.512x512.png":{"sha256":"3ea935089cc2ab3cae985c2b70f54fce4f4929e654416037c728107df2c7310d","bytes":33595},"index.apple-touch-icon.png":{"sha256":"ff44425cc4b3d1fd46c5bd7cc0a847d7356314fdff5760313fc15814dc6c174d","bytes":10199},"index.audio.position.worklet.js":{"sha256":"be33985bc7160d6bf9646f259cd86b259cd67b02ccb297ee5c44f8ac84327bc8","bytes":2973},"index.audio.worklet.js":{"sha256":"5b476a9c9ce642c0ee4256436d1bc31d9c38f868aca0f9a8e2a57c18d2dec2a3","bytes":7298},"index.html":{"sha256":"ba6d03d837b5f517336f4a2dfb9dbb6eedbb2bc4e439efd66e4957d7dab63902","bytes":7301},"index.icon.png":{"sha256":"3ea935089cc2ab3cae985c2b70f54fce4f4929e654416037c728107df2c7310d","bytes":33595},"index.js":{"sha256":"33c94cb3175f3333b82e2a3be5e8e86f77986f0aa2042b1631f6367a4e5bb6ba","bytes":279815},"index.manifest.json":{"sha256":"7169e2090ddc431d074cf956c3706f97a14e769418d0ddbfe4c5a409039dd523","bytes":351},"index.offline.html":{"sha256":"1f336c5bb20ff7d60c7b4f3e8f988ea156a7cf657bf2e1d7989bd04f6817c2f5","bytes":488},"index.png":{"sha256":"3cb4495c0b98dfbe4b663cbf2b6836473572339beb66d902367893162a70be0e","bytes":21443},"index.wasm":{"sha256":"fc74679e3b97f76878947fcd4fbe1268cbfa6188182a2e33bbc3f5dc9bfa57d0","bytes":39514754},"stickie-game-a862f69d3b8b9389.pck":{"sha256":"a862f69d3b8b9389215dba3351ece6a544c22a44d55e3a359deb14981f819676","bytes":1139396},"updates.js":{"sha256":"10e48a2040bf22c62a2d6b1ed4bbd05056d2c03f16324526734789d6c616debf","bytes":6345}}};
const CACHE_PREFIX = 'stickie-release-';
const CACHE_NAME = CACHE_PREFIX + RELEASE.id;
const SHARED = 'stickie-engine-assets-v1';
const ROOT = new URL('./', self.location.href);
const pendingClients = new Set();
const assetURL = (name) => new URL(name, ROOT).href;

async function checkedAsset(name, shared) {
  const asset = RELEASE.files[name];
  const url = new URL(name, ROOT);
  url.searchParams.set('asset', asset.sha256);
  const stored = await shared.match(url.href);
  if (stored) return stored;
  const response = await fetch(url.href, {cache:'reload'});
  if (!response.ok) throw new Error('Datei konnte nicht geladen werden: ' + name);
  const bytes = await response.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const hash = Array.from(new Uint8Array(digest), v => v.toString(16).padStart(2,'0')).join('');
  if (hash !== asset.sha256) throw new Error('Download unvollständig. Bitte erneut versuchen.');
  const headers = new Headers(response.headers);
  headers.delete('content-encoding'); headers.delete('content-length');
  const verified = new Response(bytes, {status:200, headers});
  // Reuse the large unchanged engine for later small gameplay updates.
  if (name === 'index.wasm' || name === 'index.js') await shared.put(url.href, verified.clone());
  return verified;
}
async function prepare(port) {
  const cache = await caches.open(CACHE_NAME);
  const shared = await caches.open(SHARED);
  const names = Object.keys(RELEASE.files);
  let done = 0;
  for (const name of names) {
    if (!(await cache.match(assetURL(name)))) {
      await cache.put(assetURL(name), await checkedAsset(name, shared));
    }
    done++;
    if (port) port.postMessage({type:'progress',done,total:names.length});
    else {
      const clients = await self.clients.matchAll({includeUncontrolled:true,type:'window'});
      for (const client of clients) if (new URL(client.url).pathname.startsWith(ROOT.pathname))
        client.postMessage({type:'STICKIE_PROGRESS',done,total:names.length});
    }
  }
  if (port) port.postMessage({type:'ready',id:RELEASE.id});
}

self.addEventListener('install', event => {
  // Installation waits for the whole playable version, including the game pack.
  event.waitUntil(prepare());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    await self.clients.claim();
    // Remove only obsolete downloaded app assets, never IndexedDB or localStorage.
    const keys = await caches.keys();
    await Promise.all(keys.filter(key =>
      (key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME) || key.startsWith('Stickie durch di-sw-cache-')
    ).map(key => caches.delete(key)));
    for (const id of pendingClients) {
      const client = await self.clients.get(id);
      if (client) {
        const url = new URL('./', ROOT); url.searchParams.set('build',RELEASE.id);
        await client.navigate(url.href);
      }
    }
    pendingClients.clear();
  })());
});
self.addEventListener('message', event => {
  if (!event.source || new URL(event.source.url).origin !== ROOT.origin ||
      !new URL(event.source.url).pathname.startsWith(ROOT.pathname)) return;
  const type = typeof event.data === 'string' ? event.data : event.data?.type;
  if (type === 'STICKIE_DOWNLOAD') {
    const port = event.ports[0];
    event.waitUntil(prepare(port).catch(error => port?.postMessage({type:'error',message:error.message})));
  } else if (type === 'STICKIE_ACTIVATE' || type === 'update' || type === 'claim') {
    // Support the already-installed older page's Update button as well.
    if (type === 'update') pendingClients.add(event.source.id);
    event.waitUntil(prepare().then(() => self.skipWaiting()));
  }
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== ROOT.origin || !url.pathname.startsWith(ROOT.pathname) || event.request.method !== 'GET') return;
  const name = url.pathname.slice(ROOT.pathname.length) || 'index.html';
  if (name === 'release.json') {
    event.respondWith(fetch(event.request, {cache:'no-store'})); return;
  }
  if (event.request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(event.request, {cache:'no-store'});
        if (response.ok) return response;
      } catch (_) {}
      const cache = await caches.open(CACHE_NAME);
      return (await cache.match(assetURL(name))) || (await cache.match(assetURL('index.offline.html')));
    })()); return;
  }
  if (Object.hasOwn(RELEASE.files,name)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      return (await cache.match(assetURL(name))) || fetch(event.request, {cache:'reload'});
    })());
  }
});
