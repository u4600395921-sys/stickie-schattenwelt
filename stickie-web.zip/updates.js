/* Update only the downloaded app files. Saved games live separately in IndexedDB. */
(() => {
  'use strict';
  const button = document.getElementById('update');
  const status = document.getElementById('update-status');
  const recovery = document.body.dataset.recovery === 'true';
  let busy = false, latest = null, registration = null;
  const say = (text) => { status.textContent = text; };
  const label = (text) => {
    button.textContent = text; button.style.display = 'block';
    const needed = busy || !['Update prüfen','Spiel aktualisieren'].includes(text);
    button.dataset.needed = String(needed); status.dataset.needed = String(needed);
  };
  const timeout = (promise, ms) => {
    let timer;
    return Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Verbindung zu langsam. Bitte erneut versuchen.')), ms);
    })]).finally(() => clearTimeout(timer));
  };
  if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', ({data}) => {
    if (data?.type !== 'STICKIE_PROGRESS') return;
    label('Update laden · ' + data.done + '/' + data.total + ' Dateien');
    say('Bitte geöffnet lassen. Dein Spielstand bleibt erhalten.');
  });
  async function release() {
    const response = await timeout(fetch('release.json?check=' + Date.now(), {cache:'no-store'}), 12000);
    if (!response.ok) throw new Error('Update konnte nicht geprüft werden.');
    const data = await response.json();
    if (typeof data.id !== 'string' || !data.id) throw new Error('Update-Datei ist unvollständig.');
    return data;
  }
  function watch(worker) {
    if (!worker) return;
    const changed = () => {
      if (busy) return;
      if (worker.state === 'installing') label('Update wird heruntergeladen …');
      if (worker.state === 'installed' && navigator.serviceWorker.controller) label('Update bereit · neu laden');
      if (worker.state === 'activated' && !recovery) {
        label('Update prüfen');
        if (latest) say('Aktueller Stand · ' + latest.label);
      }
      if (worker.state === 'redundant') {
        label('Update erneut versuchen');
        say('Download fehlgeschlagen. Dein Spielstand bleibt erhalten.');
      }
    };
    worker.addEventListener('statechange', changed);
    changed();
  }
  async function connect() {
    if (!('serviceWorker' in navigator)) throw new Error('Bitte in Safari oder Chrome öffnen.');
    if (!registration) {
      registration = await navigator.serviceWorker.register('index.service.worker.js', {updateViaCache:'none'});
      registration.addEventListener('updatefound', () => watch(registration.installing));
      watch(registration.installing);
      if (registration.waiting && !busy) label('Update bereit · neu laden');
    }
    return registration;
  }
  async function check() {
    latest = await release();
    const reg = await connect();
    await reg.update();
    if (busy) return;
    if (recovery) label('Spiel aktualisieren');
    else if (latest.id !== window.STICKIE_BUILD || reg.waiting) label('Update herunterladen');
    else if (!reg.installing) {
      label('Update prüfen');
      say('Aktueller Stand · ' + latest.label);
    }
  }
  function waitForInstall(reg) {
    if (reg.waiting) return Promise.resolve(reg.waiting);
    if (reg.active && !reg.installing) return Promise.resolve(reg.active);
    const worker = reg.installing;
    return timeout(new Promise((resolve, reject) => {
      const changed = () => {
        if (worker.state === 'installed' || worker.state === 'activated') {
          worker.removeEventListener('statechange', changed); resolve(worker);
        } else if (worker.state === 'redundant') {
          worker.removeEventListener('statechange', changed); reject(new Error('Download fehlgeschlagen. Bitte erneut versuchen.'));
        }
      };
      worker.addEventListener('statechange', changed); changed();
    }), 180000);
  }
  function download(worker) {
    return timeout(new Promise((resolve, reject) => {
      const channel = new MessageChannel();
      channel.port1.onmessage = ({data}) => {
        if (data.type === 'progress') {
          label('Update laden · ' + data.done + '/' + data.total + ' Dateien');
          say('Bitte geöffnet lassen. Dein Spielstand bleibt erhalten.');
        } else if (data.type === 'ready') {
          channel.port1.close(); resolve();
        } else if (data.type === 'error') {
          channel.port1.close(); reject(new Error(data.message));
        }
      };
      worker.postMessage({type:'STICKIE_DOWNLOAD'}, [channel.port2]);
    }), 15000);
  }
  async function apply() {
    if (busy) return;
    busy = true; button.disabled = true; button.setAttribute('aria-busy','true');
    label('Update wird geprüft …'); say('Spielstand wird beibehalten.');
    try {
      latest = await release();
      const reg = await connect();
      await reg.update();
      const worker = await waitForInstall(reg);
      await download(worker);
      label('Download fertig · Spiel wird neu geladen …');
      // Wait for activation instead of calling clients.claim() on a waiting worker.
      if (worker.state !== 'activated') {
        const active = timeout(new Promise((resolve, reject) => {
          const changed = () => {
            if (worker.state === 'activated') { worker.removeEventListener('statechange', changed); resolve(); }
            else if (worker.state === 'redundant') { worker.removeEventListener('statechange', changed); reject(new Error('Aktivierung fehlgeschlagen.')); }
          };
          worker.addEventListener('statechange', changed); changed();
        }), 15000);
        worker.postMessage({type:'STICKIE_ACTIVATE'});
        await active;
      }
      const target = new URL('./', location.href);
      target.searchParams.set('build', latest.id);
      location.replace(target.href);
    } catch (error) {
      busy = false; button.disabled = false; button.removeAttribute('aria-busy');
      label('Update erneut versuchen'); say(error.message + ' Dein Spielstand bleibt erhalten.');
    }
  }
  button.addEventListener('click', apply);
  if (recovery) say('Lädt nur Spieldateien neu. Coins, Waffen und Level bleiben gespeichert.');
  else check().catch(() => say('Update prüfen, sobald du wieder online bist.'));
})();
